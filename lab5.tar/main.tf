terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
    tls = {
      source  = "hashicorp/tls"
      version = "~> 4.0"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.0"
    }
  }
}

provider "docker" {}

# --- RSA Keypair ---

resource "tls_private_key" "ansible" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "local_sensitive_file" "private_key" {
  content         = tls_private_key.ansible.private_key_pem
  filename        = "${path.module}/ansible_key.pem"
  file_permission = "0600"
}

resource "local_file" "public_key" {
  content  = tls_private_key.ansible.public_key_openssh
  filename = "${path.module}/ansible_key.pub"
}

# --- Docker Image ---
# This uses a custom Dockerfile to install OpenSSH and inject the public key.

resource "docker_image" "ubuntu_ssh" {
  name = "ubuntu-ssh-ansible:latest"

  build {
    context = path.module
    dockerfile = "Dockerfile"
    build_args = {
      PUBLIC_KEY = tls_private_key.ansible.public_key_openssh
    }
    # Force rebuild if the public key changes
#    trigger = {
#      public_key = sha256(tls_private_key.ansible.public_key_openssh)
#    }
  }
}

# --- Docker Container ---

resource "docker_container" "ansible_target" {
  name  = "ansible-target"
  image = docker_image.ubuntu_ssh.image_id

  ports {
    internal = 22
    external = 2222
  }

  restart = "unless-stopped"
}

# --- Ansible Inventory ---

resource "local_file" "ansible_inventory" {
  content  = <<-EOT
    [targets]
    127.0.0.1 ansible_port=2222 ansible_user=ansible ansible_ssh_private_key_file=${abspath(local_sensitive_file.private_key.filename)} ansible_ssh_common_args='-o StrictHostKeyChecking=no'
  EOT
  filename = "${path.module}/ansible/inventory.ini"
}

# --- Outputs ---

output "ssh_command" {
  value = "ssh -i ansible_key.pem -p 2222 ansible@127.0.0.1"
}

output "ansible_command" {
  value = "ansible all -i inventory.ini -m ping"
}
